﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Presentation_Sermons_Default : System.Web.UI.Page
{
    string sermonID = "latest";
    public Label lblSermonVideoLink = new Label();
    public Label lblSermonAudioLink = new Label();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["sermon"] != null)
        {
            sermonID = Request.QueryString["sermon"];
            LoadSermonDetails(sermonID);
        }
        else
            LoadSermonDetails("latest");
    }

    private void LoadSermonDetails(string sermonID)
    {
        DataLink link = new DataLink();
        DataSet sermonDetails = link.GetSermonDetails(sermonID);
        if (sermonDetails != null)
        {
            FillSermonDetails(sermonDetails);
            LoadSpeakerDetails(sermonDetails.Tables[0].Rows[0]["sermonBy"].ToString(), "0");
        }
    }

    private void LoadSpeakerDetails(string speakerName, string speakerID)
    {
        DataLink link = new DataLink();
        DataSet speakerDetails = link.GetSpeakerDetails(speakerName, speakerID);
        if (speakerDetails != null)
            FillSpeakerDetails(speakerDetails);
    }

    private void FillSpeakerDetails(DataSet speakerDetails)
    {
        imgSpeaker.ImageUrl = speakerDetails.Tables[0].Rows[0]["speakerImage"].ToString();
        lblSpeakerDescr.Text = speakerDetails.Tables[0].Rows[0]["speakerDescription"].ToString();
        lblSpeakerIntroduction.Text = speakerDetails.Tables[0].Rows[0]["speakerDescription"].ToString();
        hplinkSpeakerFacebook.NavigateUrl = speakerDetails.Tables[0].Rows[0]["speakerFacebook"].ToString();
        hplinkSpeakerTwitter.NavigateUrl = speakerDetails.Tables[0].Rows[0]["speakerTwitter"].ToString();
        //hplinkSpeakerInstagram.NavigateUrl = speakerDetails.Tables[0].Rows[0]["speakerInstagram"].ToString();
        hplinkSpeakerWebsite.NavigateUrl = speakerDetails.Tables[0].Rows[0]["speakerWebsite"].ToString();
        hplinkSpeakerEmail.NavigateUrl = speakerDetails.Tables[0].Rows[0]["speakerEmail"].ToString();
        hplinkSpeakerWebsite.Visible = false;
        hplinkSpeakerEmail.Visible = false;
    }

    private void FillSermonDetails(DataSet sermonDetails)
    {
        //If No Audio Link
        if (sermonDetails.Tables[0].Rows[0]["AudioLink"].ToString() == "" || sermonDetails.Tables[0].Rows.Count == 0)
            sermonAudio.Visible = false;
        else
        {
            sermonAudio.Visible = true;
            lblSermonAudioLink.Text = sermonDetails.Tables[0].Rows[0]["AudioLink"].ToString();
            hdAudioLink.Value = sermonDetails.Tables[0].Rows[0]["AudioLink"].ToString();
        }

        //If No Video Link
        if (sermonDetails.Tables[0].Rows[0]["VideoLink"].ToString() == "" || sermonDetails.Tables[0].Rows.Count == 0)
        {
            sermonVideo.Visible = false;
            sermonVideoHead.Visible = false;
        }
        else
        {
            sermonVideo.Visible = true;
            sermonVideoHead.Visible = true;
            lblSermonVideoLink.Text = sermonDetails.Tables[0].Rows[0]["VideoLink"].ToString();
            hdVideoLink.Value = sermonDetails.Tables[0].Rows[0]["VideoLink"].ToString();
        }

        //If No Sermon Description
        if (sermonDetails.Tables[0].Rows[0]["SermonDescription"].ToString() == "" || sermonDetails.Tables[0].Rows.Count == 0)
            sermonAbout.Visible = false;
        else
        {
            sermonAbout.Visible = true;
            lblAboutSermon.Text = sermonDetails.Tables[0].Rows[0]["SermonDescription"].ToString().Replace("\n", "<br/>");
            lblAboutSermon.Text = lblAboutSermon.Text.Replace("\\n", "<br/>");
        }
        imgSermonBanner.ImageUrl = sermonDetails.Tables[0].Rows[0]["ImageLink"].ToString();
        hplinkAudioDownload.NavigateUrl = hdAudioLink.Value;
        //hplinkDownloadRes.NavigateUrl = "https://www.google.co.in/webhp?hl=en&tab=ww&ei=ozZdUouWBcL7rAf-yYCIDg&ved=0CBYQ1S4";
    }
}